#LLAMA3 - FT!
import pandas as pd
import sys
import torch
from datasets import Dataset
from peft import LoraConfig, PeftModel, get_peft_model
from transformers import AutoModelForCausalLM, AutoTokenizer, TrainingArguments, BitsAndBytesConfig, pipeline, logging
from trl import SFTTrainer
from transformers import StoppingCriteria, StoppingCriteriaList
import pickle as p
from tqdm import tqdm


#CUDA_VISIBLE_DEVICES=0 python 0.py /datasets/ankitUW/resources/grndtr_data/EN/train.csv /datasets/ankitUW/resources/grndtr_data/EN/dev.csv 0 l3-0-I/

train = sys.argv[1]#training file
dev = sys.argv[2]#dev file
topk = int(sys.argv[3])#the k value for in context learning example count.
op_dir = sys.argv[4]


if topk > 0 :
	from langchain_core.documents import Document
	from langchain_community.retrievers import BM25Retriever as BM25
	lDoc = []
	x = open(train,"r").read().strip().split("\n")# s, t
	for i in x:
		tmp = i.split("|\t|")
		s = tmp[0]
		t = tmp[1]
		tmp = Document(page_content = s, metadata = dict(aws = s, man = t))
		lDoc.append(tmp)
	retbm25 = BM25.from_documents(lDoc)
	retbm25.k = topk + 1


def procData(f):
	df = pd.DataFrame()
	x = open(f,"r").read().strip().split("\n")# s, t
	src = []
	trg = []
	comb = []
	prefix = "<|start_header_id|>system<|end_header_id|>\n\nYou are an automatic speech recognition transcript error correction tool. You are shown the automatically generated transcripts of calls between a user and a customer service support agent. Check the speech transcript sentence and correct all possible errors.<|eot_id|>\n<|start_header_id|>user<|end_header_id|>\n\n"
	example_instr = "Here are some examples of speech transcripts and their corrections :<|eot_id|>\n"
	for j in x:
		tmp = j.split("|\t|")
		assert(len(tmp) == 2)
		src.append(tmp[0])
		trg.append(tmp[1])
		if topk > 0:
			c = prefix + example_instr
			retdocs = retbm25.invoke(tmp[0])
			examples = []
			for i in retdocs:
				if i.metadata["aws"] != tmp[0]:
					examples.append({"aws": i.metadata["aws"], "man": i.metadata["man"]})
			assert(len(examples) >= topk)
			examples = examples[:topk]
			for e in examples:
				c += "<sent> Speech Transcript: " + e["aws"] +"\nCorrection: " + e["man"] + "</sent>\n"
			c += "<sent> Speech Transcript: " + tmp[0] +"\nCorrection: " + tmp[1] + "</sent>"
		else:
			c = prefix + "<sent> Speech Transcript: " + tmp[0] +"\nCorrection: " + tmp[1] + "</sent>"
		comb.append(c)
	df["text"] = comb
	return df


train_ds = procData(train)
val_ds = procData(dev)
train_dataset = Dataset.from_pandas(train_ds)
val_dataset = Dataset.from_pandas(val_ds)


model_path = "/datasets/model/Meta-Llama-3-8B-Instruct"
#model_path = "/datasets/model/Meta-Llama-3-8B-Instruct"

# QLoRA parameters
lora_r = 128
lora_alpha = 32
lora_dropout = 0.1
lora_modules = ["q_proj", "v_proj", "k_poj", "o_proj"]

# bitsandbytes parameters
use_4bit = True
bnb_4bit_compute_dtype = "float16"
bnb_4bit_quant_type = "nf4"
use_nested_quant = False

# TrainingArguments parameters
op_dir = "/datasets/ankitUW/llama-ft/" + op_dir
num_train_epochs = 3
fp16 = False
bf16 = False

per_device_train_batch_size = 1
per_device_eval_batch_size = 1
gradient_accumulation_steps = 1
gradient_checkpointing = True
max_grad_norm = 0.3
learning_rate = 2e-4
weight_decay = 0.001
optim = "paged_adamw_8bit"
lr_scheduler_type = "linear"
max_steps = -1
warmup_ratio = 0.03
group_by_length = True
#save_steps = 500
#save_total_limit = 3
logging_steps = 100
load_best_model_at_end=True



# SFT parameters
max_seq_length = 512
packing = False
device_map = {"": 0}
compute_dtype = getattr(torch, bnb_4bit_compute_dtype)

bnb_config = BitsAndBytesConfig(
	load_in_4bit=use_4bit,
	bnb_4bit_quant_type=bnb_4bit_quant_type,
	bnb_4bit_compute_dtype=compute_dtype,
	bnb_4bit_use_double_quant=use_nested_quant,
)

# Check GPU compatibility with bfloat16
if compute_dtype == torch.float16 and use_4bit:
	major, _ = torch.cuda.get_device_capability()
	if major >= 8:
		print("=" * 80)
		print("Your GPU supports bfloat16: accelerate training with bf16=True")
		print("=" * 80)


model = AutoModelForCausalLM.from_pretrained(
	model_path,
	quantization_config=bnb_config,
	device_map=device_map
)
model.config.use_cache = False
model.config.pretraining_tp = 1


tokenizer = AutoTokenizer.from_pretrained(model_path, use_fast=True)
#tokenizer.pad_token = tokenizer.eos_token
tokenizer.pad_token_id = tokenizer.eos_token_id
tokenizer.padding_side = "right"

peft_config = LoraConfig(
	lora_alpha=lora_alpha,
	lora_dropout=lora_dropout,
	r=lora_r,
	bias="none",
	task_type="CAUSAL_LM",
	target_modules = lora_modules
)

#model = get_peft_model(model, peft_config)

# Set training parameters
training_arguments = TrainingArguments(
	output_dir=op_dir,
	num_train_epochs=num_train_epochs,
	per_device_train_batch_size=per_device_train_batch_size,
	gradient_accumulation_steps=gradient_accumulation_steps,
	optim=optim,
	#save_steps=save_steps,
	#save_total_limit=save_total_limit,
	logging_steps=logging_steps,
	learning_rate=learning_rate,
	weight_decay=weight_decay,
	fp16=fp16,
	bf16=bf16,
	max_grad_norm=max_grad_norm,
	max_steps=max_steps,
	warmup_ratio=warmup_ratio,
	group_by_length=group_by_length,
	lr_scheduler_type=lr_scheduler_type,
	load_best_model_at_end = load_best_model_at_end,
	report_to = "none"
)


#model = prepare_model_for_int8_training(model)
#peft_config = LoraConfig(r=64, lora_alpha=16, lora_dropout=0.1, bias="none", task_type="CAUSAL_LM")
#model = get_peft_model(model, peft_config)


trainer = SFTTrainer(
	model=model,
	train_dataset=train_dataset,
	eval_dataset=val_dataset,
	dataset_text_field="text",
	max_seq_length=max_seq_length,
	tokenizer=tokenizer,
	args=training_arguments,
	packing=packing,
	peft_config=peft_config,
)

trainer.train()

trainer.model.save_pretrained(op_dir+"final-model")


logging.set_verbosity(logging.CRITICAL)

stop_token_list = ["</sent>"]
stop_token_ids = [tokenizer(x, add_special_tokens=False)['input_ids'] for x in stop_token_list]

class StopOnTokens(StoppingCriteria):
	def __call__(self, input_ids:torch.LongTensor, scores:torch.FloatTensor, **kwargs) -> bool:
		for stop_ids in stop_token_ids:
			last_ids = input_ids[:,-len(stop_ids):].tolist()
			return stop_ids in last_ids

stop_critr = StoppingCriteriaList([StopOnTokens()])
pipe = pipeline(task="text-generation", model = model, tokenizer = tokenizer, max_new_tokens = 100, stopping_criteria=stop_critr)

dev_sents = open(dev,"r").read().strip().split("\n")
s_t_h = {"s":[], "t":[], "h":[]}

for d in tqdm(dev_sents):
	tmp = d.split("|\t|")
	assert(len(tmp) == 2)
	s = tmp[0]
	t = tmp[1]
	prefix = "<|start_header_id|>system<|end_header_id|>\n\nYou are an automatic speech recognition transcript error correction tool. You are shown the automatically generated transcripts of calls between a user and a customer service support agent. Check the speech transcript sentence and correct all possible errors.<|eot_id|>\n<|start_header_id|>user<|end_header_id|>\n\n"
	#example_instr = "\nHere are some examples of speech transcripts and their corrections :"
	c = prefix + "<sent> Speech Transcript: " + s +"\nCorrection: "
	result = pipe(c)
	h = result[0]['generated_text']
	s_t_h["s"].append(s)
	s_t_h["t"].append(t)
	s_t_h["h"].append(h)

p.dump(s_t_h, open(op_dir+"s_t_h_final.p", "wb"))

'''
#----Load the model for the kinda add and inference thing:

base_model = AutoModelForCausalLM.from_pretrained(
	model_path,
	quantization_config=bnb_config,
	device_map=device_map
)
base_model.config.use_cache = False
base_model.config.pretraining_tp = 1

new_model = op_dir+"final-model"

model = PeftModel.from_pretrained(base_model, new_model)
model = model.merge_and_unload()

# Save the model locally
model.save_pretrained(new_model)
'''